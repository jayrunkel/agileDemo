package com.mongodb.agileDemo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AgileDemoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
